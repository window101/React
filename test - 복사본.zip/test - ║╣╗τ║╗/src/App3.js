import Hooks2 from "./Hooks2";
import Counter2 from "./Counter2";
import React from "react";
import Hooks3 from "./Hook3";
function App3() {
  return (
    <>
      <Counter2 />
      <Hooks3 />
    </>
  );
}
export default App3;
